# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/mnt/models/AI/LLM/Qwen3.8-27B-Q4_K_M.gguf`
- MMPROJ: `/mnt/models/AI/LLM/Qwen3.8-27B-mmproj-BF16.gguf`
- NGL: `999`
- CTX_SIZE: `32768`
- MAX_CONTEXT_TARGET: `32768`
- N_GEN: `128`
- BATCH: `4097`
- UBATCH: `32`
- CTK: `f16`
- CTV: `f16`
- SPEC_TYPE: `mtp`
- SPEC_DRAFT_N_MAX: `3`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1/1`
- PARALLEL: `1`
- PARALLEL_LOAD: `1`
- TEMPERATURE: `0.15`
- CACHE_PROMPT: `0`
- FLASH_ATTN: `auto`
- THREADS: `auto`
- THREADS_BATCH: `auto`
- REPEATS: `1`
- CUDA_VISIBLE_DEVICES: `9,10,11`
- TURBOPREFILL: `0`
- TurboPrefill status: `TurboPrefill implementation detected; inactive (TURBOPREFILL=0)`
- TurboPrefill version: `TurboPrefill`
- llama.cpp git describe: `t0002-1191-g3d27f5bb-dirty`
- llama.cpp git commit: `3d27f5bb6348c4d79edded63b03e9a93efb2f80e`
- Server PID: `70907`
- KEEP_SERVER_RUNNING: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8/bench_reports_Qwen3.8-27B-Q4_K_M_ik/20261011_190040/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### RUN_DIR

```text
/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8
```

### CONFIG_PATH

```text
/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8/config_Qwen_3.8_ik_v3.sh
```

### LLAMA_SERVER_BIN

```text
/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8/build/bin/llama-server
```

### LOCAL_LD_LIBRARY_PATH

```text
/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8/build/bin
```

### CUDA_VISIBLE_DEVICES_effective

```text
9,10,11
```

### selected_gpu_count

```text
3
```

### selected_gpu_models

```text
NVIDIA P104-100 x3
```

### llama_server_version

```text
version: 5005 (3d27f5bb)
built with cc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0 for x86_64-linux-gnu
```

### uname

```text
Linux turboprefill 6.17.0-29-generic #29~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Mon May 11 10:30:58 UTC 2 x86_64 x86_64 x86_64 GNU/Linux
```

### lscpu

```text
Архитектура:                             x86_64
CPU op-mode(s):                          32-bit, 64-bit
Address sizes:                           39 bits physical, 48 bits virtual
Порядок байт:                            Little Endian
CPU(s):                                  4
On-line CPU(s) list:                     0-3
ID прроизводителя:                       GenuineIntel
Имя модели:                              Intel(R) Core(TM) i5-7500 CPU @ 3.40GHz
Семейство ЦПУ:                           6
Модель:                                  158
Потоков на ядро:                         1
Ядер на сокет:                           4
Сокетов:                                 1
Степпинг:                                9
CPU(s) scaling MHz:                      57%
CPU max MHz:                             3800.0000
CPU min MHz:                             800.0000
BogoMIPS:                                6799.81
Флаги:                                   fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush dts acpi mmx fxsr sse sse2 ss ht tm pbe syscall nx pdpe1gb rdtscp lm constant_tsc art arch_perfmon pebs bts rep_good nopl xtopology nonstop_tsc cpuid aperfmperf pni pclmulqdq dtes64 monitor ds_cpl smx est tm2 ssse3 sdbg fma cx16 xtpr pdcm pcid sse4_1 sse4_2 x2apic movbe popcnt tsc_deadline_timer aes xsave avx f16c rdrand lahf_lm abm 3dnowprefetch cpuid_fault pti ssbd ibrs ibpb stibp fsgsbase tsc_adjust bmi1 avx2 smep bmi2 erms invpcid mpx rdseed adx smap clflushopt intel_pt xsaveopt xsavec xgetbv1 xsaves dtherm ida arat pln pts hwp hwp_notify hwp_act_window hwp_epp md_clear flush_l1d arch_capabilities
L1d cache:                               128 KiB (4 instances)
L1i cache:                               128 KiB (4 instances)
L2 cache:                                1 MiB (4 instances)
L3 cache:                                6 MiB (1 instance)
NUMA node(s):                            1
NUMA node0 CPU(s):                       0-3
Vulnerability Gather data sampling:      Vulnerable
Vulnerability Ghostwrite:                Not affected
Vulnerability Indirect target selection: Not affected
Vulnerability Itlb multihit:             KVM: Mitigation: VMX unsupported
Vulnerability L1tf:                      Mitigation; PTE Inversion
Vulnerability Mds:                       Mitigation; Clear CPU buffers; SMT disabled
Vulnerability Meltdown:                  Mitigation; PTI
Vulnerability Mmio stale data:           Mitigation; Clear CPU buffers; SMT disabled
Vulnerability Old microcode:             Not affected
Vulnerability Reg file data sampling:    Not affected
Vulnerability Retbleed:                  Mitigation; IBRS
Vulnerability Spec rstack overflow:      Not affected
Vulnerability Spec store bypass:         Mitigation; Speculative Store Bypass disabled via prctl
Vulnerability Spectre v1:                Mitigation; usercopy/swapgs barriers and __user pointer sanitization
Vulnerability Spectre v2:                Mitigation; IBRS; IBPB conditional; STIBP disabled; RSB filling; PBRSB-eIBRS Not affected; BHI Not affected
Vulnerability Srbds:                     Mitigation; Microcode
Vulnerability Tsa:                       Not affected
Vulnerability Tsx async abort:           Mitigation; TSX disabled
Vulnerability Vmscape:                   Mitigation; IBPB before exit to userspace
```

### motherboard_vendor

```text
ASUSTeK COMPUTER INC.
```

### motherboard_name

```text
B250 MINING EXPERT
```

### motherboard_version

```text
Rev X.0x
```

### memory_summary

```text
всего        занят        своб      общая  буф/врем.   доступно
Память:         15Gi       1.4Gi       5.2Gi       176Mi       9.3Gi        14Gi
Подкачка:       23Gi       4.2Gi        19Gi
```

### memory_modules

```text
unavailable: Command '['dmidecode', '--type', '17']' returned non-zero exit status 1.
```

### nvidia_smi

```text
0, NVIDIA P104-100, 00000000:01:00.0, 535.309.01, 8192 MiB, 1, 1
1, NVIDIA P104-100, 00000000:02:00.0, 535.309.01, 8192 MiB, 1, 1
2, NVIDIA P104-100, 00000000:0A:00.0, 535.309.01, 8192 MiB, 1, 1
3, NVIDIA P104-100, 00000000:0C:00.0, 535.309.01, 8192 MiB, 1, 1
4, NVIDIA P104-100, 00000000:0D:00.0, 535.309.01, 8192 MiB, 1, 1
5, NVIDIA P104-100, 00000000:0E:00.0, 535.309.01, 8192 MiB, 1, 1
6, NVIDIA P104-100, 00000000:0F:00.0, 535.309.01, 8192 MiB, 1, 1
7, NVIDIA P104-100, 00000000:10:00.0, 535.309.01, 8192 MiB, 1, 1
8, NVIDIA P104-100, 00000000:11:00.0, 535.309.01, 8192 MiB, 1, 1
9, NVIDIA P104-100, 00000000:12:00.0, 535.309.01, 8192 MiB, 1, 1
10, NVIDIA P104-100, 00000000:13:00.0, 535.309.01, 8192 MiB, 1, 1
11, NVIDIA P104-100, 00000000:14:00.0, 535.309.01, 8192 MiB, 1, 1
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2023 NVIDIA Corporation
Built on Fri_Jan__6_16:45:21_PST_2023
Cuda compilation tools, release 12.0, V12.0.140
Build cuda_12.0.r12.0/compiler.32267302_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

### git_describe

```text
t0002-1191-g3d27f5bb-dirty
```

### git_commit

```text
3d27f5bb6348c4d79edded63b03e9a93efb2f80e
```

### git_last_commit

```text
2026-10-05 15:12:33 +0200
CUDA implementation for IQ4_KS_R16 (#2586)
```

### git_turboprefill_hint

```text
none
```

### model_path

```text
/mnt/models/AI/LLM/Qwen3.8-27B-Q4_K_M.gguf
```

### model_filename

```text
Qwen3.8-27B-Q4_K_M.gguf
```

### model_size_bytes

```text
16810714432
```

### model_size_gib

```text
15.656
```

### gguf_architecture

```text
qwen35
```

### gguf_tensor_count

```text
866
```

### gguf_tensor_types

```text
F32:360, Q4_K:439, Q6_K:67
```

### model_sha256

```text
disabled (MODEL_HASH=0)
```

### TurboPrefill runtime markers

```text
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=4097 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=4097 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=4097 requested_outputs=4097 logits_mib=3880.95 embd_mib=80.02 buf_used_mib=3960.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=4097 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=4097 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=4097 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=4097 requested_outputs=4097 logits_mib=3880.95 embd_mib=80.02 buf_used_mib=3960.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=4097 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=654 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=654 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=654 requested_outputs=654 logits_mib=619.51 embd_mib=12.77 buf_used_mib=632.29 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=654 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=263 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=263 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=263 requested_outputs=263 logits_mib=249.13 embd_mib=5.14 buf_used_mib=254.27 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=263 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=536 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=536 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=536 requested_outputs=536 logits_mib=507.73 embd_mib=10.47 buf_used_mib=518.20 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=536 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=1077 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1077 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1077 requested_outputs=1077 logits_mib=1020.21 embd_mib=21.04 buf_used_mib=1041.24 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=1077 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=2325 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=2325 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=2325 requested_outputs=2325 logits_mib=2202.39 embd_mib=45.41 buf_used_mib=2247.80 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=2325 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=4097 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=4097 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=4097 requested_outputs=4097 logits_mib=3880.95 embd_mib=80.02 buf_used_mib=3960.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=4097 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=186 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=186 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=186 requested_outputs=186 logits_mib=176.19 embd_mib=3.63 buf_used_mib=179.82 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=186 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=4097 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=4097 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=4097 requested_outputs=4097 logits_mib=3880.95 embd_mib=80.02 buf_used_mib=3960.97 buf_alloc_mib=3960.97
llama_decode_internal: TurboPrefill V8 requested=0 active=0 n_tokens=4097 n_ubatch=32 real_ubatch=0 n_seq_tokens=0 n_seqs=0 n_seqs_unq=0 equal=0 n_outputs_ubatch=0 layout_hash=0 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=3960.97
```

## Server command

```bash
/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8/build/bin/llama-server -m /mnt/models/AI/LLM/Qwen3.8-27B-Q4_K_M.gguf --host 0.0.0.0 --port 8082 -ngl 999 -c 32768 --override-kv llama.context_length=int:32768 -b 4097 -ub 32 -np 1 -ctk f16 -ctv f16 -sm layer -ts 1/1/1 --parallel-load --flash-attn auto --no-warmup --mmproj /mnt/models/AI/LLM/Qwen3.8-27B-mmproj-BF16.gguf --spec-type mtp:n_max=3
```

Server PID: `70907`  
Stop command: `kill -INT 70907`

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 268 | 128 | 63.83 | 4.20 | 10.14 | 12.63 | 22.16 |
| ctx_000512.txt | 1 | 1 | 541 | 128 | 76.74 | 7.05 | 10.35 | 12.37 | 21.84 |
| ctx_001024.txt | 1 | 1 | 1082 | 128 | 85.90 | 12.60 | 9.35 | 13.69 | 27.56 |
| ctx_002048.txt | 1 | 1 | 2330 | 128 | 90.69 | 25.69 | 9.87 | 12.97 | 41.12 |
| ctx_004096.txt | 1 | 1 | 4288 | 128 | 84.69 | 50.63 | 9.62 | 13.31 | 71.14 |
| ctx_008192.txt | 1 | 1 | 8853 | 128 | 85.97 | 102.98 | 9.00 | 14.22 | 140.15 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 0.0 | 0.0 | 51.8 | 51.8 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 70.0 | 70.0 | 52.8 | 52.8 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 0.0 | 0.0 | 53.5 | 53.5 | 6293 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 36.7 | 100.0 | 64.5 | 106.9 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 30.6 | 80.0 | 49.4 | 85.8 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 50.9 | 100.0 | 70.6 | 111.2 | 6293 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 10.3 | 21.0 | 64.6 | 104.5 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 40.0 | 73.0 | 67.0 | 104.8 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 98.3 | 100.0 | 46.6 | 47.8 | 6293 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 24.1 | 44.0 | 65.0 | 124.2 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 42.9 | 64.0 | 53.2 | 101.0 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 31.0 | 73.0 | 63.9 | 113.5 | 6293 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 38.0 | 68.0 | 80.1 | 103.0 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 44.0 | 75.0 | 58.5 | 111.3 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 69.6 | 100.0 | 63.9 | 95.3 | 6293 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 40.7 | 99.0 | 67.4 | 117.5 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 21.0 | 48.0 | 68.4 | 130.8 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 37.1 | 73.0 | 52.3 | 81.6 | 6293 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 51.1 | 81.0 | 58.5 | 103.7 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 42.5 | 100.0 | 71.6 | 111.5 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 82.6 | 100.0 | 71.9 | 127.5 | 6293 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 29.8 | 50.0 | 54.4 | 130.9 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 19.4 | 55.0 | 85.4 | 128.8 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 48.0 | 81.0 | 53.7 | 83.3 | 6293 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 44.9 | 100.0 | 58.7 | 102.2 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 36.3 | 86.0 | 69.4 | 141.1 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 74.5 | 100.0 | 64.2 | 122.1 | 6293 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 21.2 | 51.0 | 45.0 | 60.7 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 29.4 | 56.0 | 63.4 | 135.1 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 19.0 | 41.0 | 53.8 | 87.1 | 6293 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 38.4 | 88.0 | 58.5 | 110.8 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 37.9 | 97.0 | 66.2 | 144.3 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 68.2 | 100.0 | 63.5 | 121.8 | 6293 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 37.9 | 88.0 | 59.4 | 100.6 | 7573 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 27.9 | 85.0 | 66.9 | 130.2 | 6289 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 61.0 | 100.0 | 65.2 | 143.2 | 6293 |


## CPU / RAM / swap load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 28.8 %, max 28.8 %

RAM used: avg 12166 MiB, max 12166 MiB, avg 76.6 %, max 76.6 %

Swap used: avg 4565 MiB, max 4565 MiB, avg 18.6 %, max 18.6 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 6.0 | 6.0 |
| 1 | 4.6 | 4.6 |
| 2 | 43.5 | 43.5 |
| 3 | 61.6 | 61.6 |

Decode stage:

CPU total: avg 31.9 %, max 35.4 %

RAM used: avg 11868 MiB, max 12180 MiB, avg 74.8 %, max 76.7 %

Swap used: avg 4564 MiB, max 4565 MiB, avg 18.6 %, max 18.6 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 7.8 | 12.6 |
| 1 | 10.4 | 16.4 |
| 2 | 9.5 | 17.0 |
| 3 | 99.8 | 100.0 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 32.1 %, max 34.5 %

RAM used: avg 12427 MiB, max 12465 MiB, avg 78.3 %, max 78.5 %

Swap used: avg 4557 MiB, max 4557 MiB, avg 18.5 %, max 18.5 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 8.8 | 11.9 |
| 1 | 9.7 | 13.1 |
| 2 | 10.3 | 14.6 |
| 3 | 99.8 | 100.0 |

Decode stage:

CPU total: avg 32.8 %, max 33.8 %

RAM used: avg 12344 MiB, max 12388 MiB, avg 77.8 %, max 78.0 %

Swap used: avg 4557 MiB, max 4557 MiB, avg 18.5 %, max 18.5 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 9.4 | 12.2 |
| 1 | 10.7 | 13.4 |
| 2 | 11.0 | 13.1 |
| 3 | 99.9 | 100.0 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 33.1 %, max 34.9 %

RAM used: avg 12851 MiB, max 12880 MiB, avg 81.0 %, max 81.1 %

Swap used: avg 4557 MiB, max 4557 MiB, avg 18.5 %, max 18.5 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 9.8 | 13.9 |
| 1 | 13.8 | 20.7 |
| 2 | 9.0 | 12.1 |
| 3 | 99.4 | 100.0 |

Decode stage:

CPU total: avg 32.8 %, max 33.5 %

RAM used: avg 12783 MiB, max 12814 MiB, avg 80.5 %, max 80.7 %

Swap used: avg 4557 MiB, max 4557 MiB, avg 18.5 %, max 18.5 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 9.7 | 11.7 |
| 1 | 10.4 | 14.3 |
| 2 | 11.0 | 16.0 |
| 3 | 99.9 | 100.0 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 34.4 %, max 40.9 %

RAM used: avg 13208 MiB, max 13337 MiB, avg 83.2 %, max 84.0 %

Swap used: avg 4585 MiB, max 4588 MiB, avg 18.7 %, max 18.7 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 12.2 | 15.6 |
| 1 | 14.0 | 32.1 |
| 2 | 89.5 | 100.0 |
| 3 | 21.7 | 98.1 |

Decode stage:

CPU total: avg 32.6 %, max 33.9 %

RAM used: avg 13234 MiB, max 13270 MiB, avg 83.4 %, max 83.6 %

Swap used: avg 4584 MiB, max 4585 MiB, avg 18.7 %, max 18.7 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 9.4 | 14.5 |
| 1 | 11.7 | 15.5 |
| 2 | 99.9 | 100.0 |
| 3 | 9.3 | 12.6 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 32.5 %, max 34.9 %

RAM used: avg 13594 MiB, max 13740 MiB, avg 85.6 %, max 86.6 %

Swap used: avg 4775 MiB, max 4777 MiB, avg 19.4 %, max 19.4 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 18.1 | 88.3 |
| 1 | 11.9 | 19.3 |
| 2 | 61.3 | 99.5 |
| 3 | 38.8 | 100.0 |

Decode stage:

CPU total: avg 27.8 %, max 33.2 %

RAM used: avg 13665 MiB, max 13716 MiB, avg 86.1 %, max 86.4 %

Swap used: avg 4885 MiB, max 4929 MiB, avg 19.9 %, max 20.1 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 69.9 | 100.0 |
| 1 | 9.9 | 12.2 |
| 2 | 9.2 | 12.1 |
| 3 | 22.1 | 69.4 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 29.7 %, max 34.9 %

RAM used: avg 12685 MiB, max 13819 MiB, avg 79.9 %, max 87.0 %

Swap used: avg 5478 MiB, max 6116 MiB, avg 22.3 %, max 24.9 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 19.1 | 100.0 |
| 1 | 13.5 | 46.9 |
| 2 | 34.1 | 100.0 |
| 3 | 52.0 | 100.0 |

Decode stage:

CPU total: avg 31.9 %, max 34.0 %

RAM used: avg 12755 MiB, max 12898 MiB, avg 80.3 %, max 81.2 %

Swap used: avg 5386 MiB, max 5391 MiB, avg 21.9 %, max 21.9 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 18.8 | 100.0 |
| 1 | 10.8 | 14.9 |
| 2 | 10.3 | 13.8 |
| 3 | 87.6 | 100.0 |

