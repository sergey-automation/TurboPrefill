# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/mnt/models/AI/LLM/Qwen3.8-27B-Q4_K_M.gguf`
- MMPROJ: `/mnt/models/AI/LLM/Qwen3.8-27B-mmproj-BF16.gguf`
- NGL: `999`
- CTX_SIZE: `32768`
- MAX_CONTEXT_TARGET: `32768`
- N_GEN: `128`
- BATCH: `4097`
- UBATCH: `32`
- CTK: `f16`
- CTV: `f16`
- SPEC_TYPE: `mtp`
- SPEC_DRAFT_N_MAX: `3`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1/1`
- PARALLEL: `1`
- PARALLEL_LOAD: `1`
- TEMPERATURE: `0.15`
- CACHE_PROMPT: `0`
- FLASH_ATTN: `auto`
- THREADS: `auto`
- THREADS_BATCH: `auto`
- REPEATS: `1`
- CUDA_VISIBLE_DEVICES: `9,10,11`
- TURBOPREFILL: `1`
- TurboPrefill status: `active (TURBOPREFILL=1)`
- TurboPrefill version: `TurboPrefill:`
- llama.cpp git describe: `t0002-1191-g3d27f5bb-dirty`
- llama.cpp git commit: `3d27f5bb6348c4d79edded63b03e9a93efb2f80e`
- Server PID: `69010`
- KEEP_SERVER_RUNNING: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8/bench_reports_Qwen3.8-27B-Q4_K_M_ik/20261011_174821/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### RUN_DIR

```text
/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8
```

### CONFIG_PATH

```text
/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8/config_Qwen_3.8_ik_v3.sh
```

### LLAMA_SERVER_BIN

```text
/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8/build/bin/llama-server
```

### LOCAL_LD_LIBRARY_PATH

```text
/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8/build/bin
```

### CUDA_VISIBLE_DEVICES_effective

```text
9,10,11
```

### selected_gpu_count

```text
3
```

### selected_gpu_models

```text
NVIDIA P104-100 x3
```

### llama_server_version

```text
version: 5005 (3d27f5bb)
built with cc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0 for x86_64-linux-gnu
```

### uname

```text
Linux turboprefill 6.17.0-29-generic #29~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Mon May 11 10:30:58 UTC 2 x86_64 x86_64 x86_64 GNU/Linux
```

### lscpu

```text
Архитектура:                             x86_64
CPU op-mode(s):                          32-bit, 64-bit
Address sizes:                           39 bits physical, 48 bits virtual
Порядок байт:                            Little Endian
CPU(s):                                  4
On-line CPU(s) list:                     0-3
ID прроизводителя:                       GenuineIntel
Имя модели:                              Intel(R) Core(TM) i5-7500 CPU @ 3.40GHz
Семейство ЦПУ:                           6
Модель:                                  158
Потоков на ядро:                         1
Ядер на сокет:                           4
Сокетов:                                 1
Степпинг:                                9
CPU(s) scaling MHz:                      97%
CPU max MHz:                             3800.0000
CPU min MHz:                             800.0000
BogoMIPS:                                6799.81
Флаги:                                   fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush dts acpi mmx fxsr sse sse2 ss ht tm pbe syscall nx pdpe1gb rdtscp lm constant_tsc art arch_perfmon pebs bts rep_good nopl xtopology nonstop_tsc cpuid aperfmperf pni pclmulqdq dtes64 monitor ds_cpl smx est tm2 ssse3 sdbg fma cx16 xtpr pdcm pcid sse4_1 sse4_2 x2apic movbe popcnt tsc_deadline_timer aes xsave avx f16c rdrand lahf_lm abm 3dnowprefetch cpuid_fault pti ssbd ibrs ibpb stibp fsgsbase tsc_adjust bmi1 avx2 smep bmi2 erms invpcid mpx rdseed adx smap clflushopt intel_pt xsaveopt xsavec xgetbv1 xsaves dtherm ida arat pln pts hwp hwp_notify hwp_act_window hwp_epp md_clear flush_l1d arch_capabilities
L1d cache:                               128 KiB (4 instances)
L1i cache:                               128 KiB (4 instances)
L2 cache:                                1 MiB (4 instances)
L3 cache:                                6 MiB (1 instance)
NUMA node(s):                            1
NUMA node0 CPU(s):                       0-3
Vulnerability Gather data sampling:      Vulnerable
Vulnerability Ghostwrite:                Not affected
Vulnerability Indirect target selection: Not affected
Vulnerability Itlb multihit:             KVM: Mitigation: VMX unsupported
Vulnerability L1tf:                      Mitigation; PTE Inversion
Vulnerability Mds:                       Mitigation; Clear CPU buffers; SMT disabled
Vulnerability Meltdown:                  Mitigation; PTI
Vulnerability Mmio stale data:           Mitigation; Clear CPU buffers; SMT disabled
Vulnerability Old microcode:             Not affected
Vulnerability Reg file data sampling:    Not affected
Vulnerability Retbleed:                  Mitigation; IBRS
Vulnerability Spec rstack overflow:      Not affected
Vulnerability Spec store bypass:         Mitigation; Speculative Store Bypass disabled via prctl
Vulnerability Spectre v1:                Mitigation; usercopy/swapgs barriers and __user pointer sanitization
Vulnerability Spectre v2:                Mitigation; IBRS; IBPB conditional; STIBP disabled; RSB filling; PBRSB-eIBRS Not affected; BHI Not affected
Vulnerability Srbds:                     Mitigation; Microcode
Vulnerability Tsa:                       Not affected
Vulnerability Tsx async abort:           Mitigation; TSX disabled
Vulnerability Vmscape:                   Mitigation; IBPB before exit to userspace
```

### motherboard_vendor

```text
ASUSTeK COMPUTER INC.
```

### motherboard_name

```text
B250 MINING EXPERT
```

### motherboard_version

```text
Rev X.0x
```

### memory_summary

```text
всего        занят        своб      общая  буф/врем.   доступно
Память:         15Gi       4.7Gi       6.8Gi       176Mi       4.4Gi        10Gi
Подкачка:       23Gi       730Mi        23Gi
```

### memory_modules

```text
unavailable: Command '['dmidecode', '--type', '17']' returned non-zero exit status 1.
```

### nvidia_smi

```text
0, NVIDIA P104-100, 00000000:01:00.0, 535.309.01, 8192 MiB, 1, 1
1, NVIDIA P104-100, 00000000:02:00.0, 535.309.01, 8192 MiB, 1, 1
2, NVIDIA P104-100, 00000000:0A:00.0, 535.309.01, 8192 MiB, 1, 1
3, NVIDIA P104-100, 00000000:0C:00.0, 535.309.01, 8192 MiB, 1, 1
4, NVIDIA P104-100, 00000000:0D:00.0, 535.309.01, 8192 MiB, 1, 1
5, NVIDIA P104-100, 00000000:0E:00.0, 535.309.01, 8192 MiB, 1, 1
6, NVIDIA P104-100, 00000000:0F:00.0, 535.309.01, 8192 MiB, 1, 1
7, NVIDIA P104-100, 00000000:10:00.0, 535.309.01, 8192 MiB, 1, 1
8, NVIDIA P104-100, 00000000:11:00.0, 535.309.01, 8192 MiB, 1, 1
9, NVIDIA P104-100, 00000000:12:00.0, 535.309.01, 8192 MiB, 1, 1
10, NVIDIA P104-100, 00000000:13:00.0, 535.309.01, 8192 MiB, 1, 1
11, NVIDIA P104-100, 00000000:14:00.0, 535.309.01, 8192 MiB, 1, 1
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2023 NVIDIA Corporation
Built on Fri_Jan__6_16:45:21_PST_2023
Cuda compilation tools, release 12.0, V12.0.140
Build cuda_12.0.r12.0/compiler.32267302_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

### git_describe

```text
t0002-1191-g3d27f5bb-dirty
```

### git_commit

```text
3d27f5bb6348c4d79edded63b03e9a93efb2f80e
```

### git_last_commit

```text
2026-10-05 15:12:33 +0200
CUDA implementation for IQ4_KS_R16 (#2586)
```

### git_turboprefill_hint

```text
none
```

### model_path

```text
/mnt/models/AI/LLM/Qwen3.8-27B-Q4_K_M.gguf
```

### model_filename

```text
Qwen3.8-27B-Q4_K_M.gguf
```

### model_size_bytes

```text
16810714432
```

### model_size_gib

```text
15.656
```

### gguf_architecture

```text
qwen35
```

### gguf_tensor_count

```text
866
```

### gguf_tensor_types

```text
F32:360, Q4_K:439, Q6_K:67
```

### model_sha256

```text
disabled (MODEL_HASH=0)
```

### TurboPrefill runtime markers

```text
srv    load_model: TurboPrefill: CUDA Graphs disabled for target and draft contexts
llama_init_from_model: TurboPrefill MTP compact output preallocation: logits_rows=129 embd_rows=4097 size=202.22 MiB
llama_init_from_model: TurboPrefill MTP compact output preallocation: logits_rows=129 embd_rows=4097 size=202.22 MiB
llama_decode_internal: TurboPrefill V8 requested=1 active=1 n_tokens=4097 n_ubatch=32 real_ubatch=32 n_seq_tokens=32 n_seqs=1 n_seqs_unq=1 equal=1 n_outputs_ubatch=1 layout_hash=3140202756796714854 full_ubatches=128 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=129 n_seq_max=1 causal=1 compact_mtp=1 n_outputs_embd=4097 requested_outputs=4097 logits_mib=122.20 embd_mib=80.02 buf_used_mib=202.22 buf_alloc_mib=202.22
turboprefill: version=TurboPrefill_ik_llama.cpp_3d27f5bb_V8 accumulation_us=2461264 compute_us=19696976 total_us=22158240
llama_decode_internal: TurboPrefill V8 requested=1 active=0 n_tokens=4097 n_ubatch=32 real_ubatch=32 n_seq_tokens=32 n_seqs=1 n_seqs_unq=1 equal=1 n_outputs_ubatch=0 layout_hash=3140203856308343065 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=202.22
llama_decode_internal: TurboPrefill V8 requested=1 active=1 n_tokens=4097 n_ubatch=32 real_ubatch=32 n_seq_tokens=32 n_seqs=1 n_seqs_unq=1 equal=1 n_outputs_ubatch=1 layout_hash=3140202756796714854 full_ubatches=128 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=129 n_seq_max=1 causal=1 compact_mtp=1 n_outputs_embd=4097 requested_outputs=4097 logits_mib=122.20 embd_mib=80.02 buf_used_mib=202.22 buf_alloc_mib=202.22
turboprefill: version=TurboPrefill_ik_llama.cpp_3d27f5bb_V8 accumulation_us=2190906 compute_us=21617449 total_us=23808355
llama_decode_internal: TurboPrefill V8 requested=1 active=0 n_tokens=4097 n_ubatch=32 real_ubatch=32 n_seq_tokens=32 n_seqs=1 n_seqs_unq=1 equal=1 n_outputs_ubatch=0 layout_hash=3140203856308343065 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=202.22
llama_decode_internal: TurboPrefill V8 requested=1 active=1 n_tokens=654 n_ubatch=32 real_ubatch=32 n_seq_tokens=32 n_seqs=1 n_seqs_unq=1 equal=1 n_outputs_ubatch=1 layout_hash=3140202756796714854 full_ubatches=20 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=21 n_seq_max=1 causal=1 compact_mtp=1 n_outputs_embd=654 requested_outputs=654 logits_mib=19.89 embd_mib=12.77 buf_used_mib=32.67 buf_alloc_mib=202.22
turboprefill: version=TurboPrefill_ik_llama.cpp_3d27f5bb_V8 accumulation_us=324991 compute_us=3806594 total_us=4131585
llama_decode_internal: TurboPrefill V8 requested=1 active=0 n_tokens=654 n_ubatch=32 real_ubatch=32 n_seq_tokens=32 n_seqs=1 n_seqs_unq=1 equal=1 n_outputs_ubatch=0 layout_hash=3140203856308343065 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=202.22
llama_decode_internal: TurboPrefill V8 requested=1 active=1 n_tokens=263 n_ubatch=32 real_ubatch=32 n_seq_tokens=32 n_seqs=1 n_seqs_unq=1 equal=1 n_outputs_ubatch=1 layout_hash=3140202756796714854 full_ubatches=8 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=9 n_seq_max=1 causal=1 compact_mtp=1 n_outputs_embd=263 requested_outputs=263 logits_mib=8.53 embd_mib=5.14 buf_used_mib=13.66 buf_alloc_mib=202.22
turboprefill: version=TurboPrefill_ik_llama.cpp_3d27f5bb_V8 accumulation_us=105162 compute_us=1279415 total_us=1384577
llama_decode_internal: TurboPrefill V8 requested=1 active=0 n_tokens=263 n_ubatch=32 real_ubatch=32 n_seq_tokens=32 n_seqs=1 n_seqs_unq=1 equal=1 n_outputs_ubatch=0 layout_hash=3140203856308343065 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=202.22
llama_decode_internal: TurboPrefill V8 requested=1 active=1 n_tokens=536 n_ubatch=32 real_ubatch=32 n_seq_tokens=32 n_seqs=1 n_seqs_unq=1 equal=1 n_outputs_ubatch=1 layout_hash=3140202756796714854 full_ubatches=16 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=17 n_seq_max=1 causal=1 compact_mtp=1 n_outputs_embd=536 requested_outputs=536 logits_mib=16.10 embd_mib=10.47 buf_used_mib=26.57 buf_alloc_mib=202.22
turboprefill: version=TurboPrefill_ik_llama.cpp_3d27f5bb_V8 accumulation_us=224108 compute_us=2467095 total_us=2691203
llama_decode_internal: TurboPrefill V8 requested=1 active=0 n_tokens=536 n_ubatch=32 real_ubatch=32 n_seq_tokens=32 n_seqs=1 n_seqs_unq=1 equal=1 n_outputs_ubatch=0 layout_hash=3140203856308343065 full_ubatches=0 devices=3 split_mode=1 nextn_layers=1 mtp_op=1 embeddings=1 mtp=1 has_mtp=1 emb_gate=1 n_outputs=1 n_seq_max=1 causal=1 compact_mtp=0 n_outputs_embd=1 requested_outputs=1 logits_mib=0.95 embd_mib=0.02 buf_used_mib=0.97 buf_alloc_mib=202.22
llama_decode_internal: TurboPrefill V8 requested=1 active=1 n_tokens=1077 n_ubatch=32 real_ubatch=32 n_seq_tokens=32 n_seqs=1 n_seqs_unq=1 equal=1 n_outputs_ubatch=1 layout_hash=3140202756796714854 full_ubatches=33 devices=3 split_mode=1 nextn_layers=1 mtp_op=0 embeddings=0 mtp=1 has_mtp=1 emb_gate=1 n_outputs=34 n_seq_max=1 causal=1 compact_mtp=1 n_outputs_embd=1077 requested_outputs=1077 logits_mib=32.21 embd_mib=21.04 buf_used_mib=53.24 buf_alloc_mib=202.22
turboprefill: version=TurboPrefill_ik_llama.cpp_3d27f5bb_V8 accumulation_us=526223 compute_us=5004227 total_us=5530450
```

## Server command

```bash
/home/serg/workspace/versions/TurboPrefill_ik_llama.cpp_3d27f5bb_V8/build/bin/llama-server -m /mnt/models/AI/LLM/Qwen3.8-27B-Q4_K_M.gguf --host 0.0.0.0 --port 8082 -ngl 999 -c 32768 --override-kv llama.context_length=int:32768 -b 4097 -ub 32 -np 1 -ctk f16 -ctv f16 -sm layer -ts 1/1/1 --parallel-load --flash-attn auto --no-warmup --mmproj /mnt/models/AI/LLM/Qwen3.8-27B-mmproj-BF16.gguf --spec-type mtp:n_max=3
```

Server PID: `69010`  
Stop command: `kill -INT 69010`

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 268 | 128 | 78.01 | 3.44 | 10.13 | 12.63 | 26.06 |
| ctx_000512.txt | 1 | 1 | 541 | 128 | 113.20 | 4.78 | 9.52 | 13.45 | 20.66 |
| ctx_001024.txt | 1 | 1 | 1082 | 128 | 138.62 | 7.81 | 9.34 | 13.71 | 24.49 |
| ctx_002048.txt | 1 | 1 | 2330 | 128 | 156.64 | 14.88 | 9.86 | 12.98 | 29.42 |
| ctx_004096.txt | 1 | 1 | 4288 | 128 | 134.44 | 31.90 | 9.62 | 13.31 | 51.18 |
| ctx_008192.txt | 1 | 1 | 8853 | 128 | 147.22 | 60.14 | 9.59 | 13.35 | 95.53 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 0.0 | 0.0 | 42.6 | 42.6 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 0.0 | 0.0 | 43.9 | 43.9 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 0.0 | 0.0 | 44.0 | 44.0 | 6281 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 26.8 | 100.0 | 72.2 | 141.3 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 30.6 | 100.0 | 54.3 | 94.5 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 34.3 | 73.0 | 54.6 | 132.4 | 6281 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 46.0 | 92.0 | 70.4 | 98.2 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 49.5 | 99.0 | 70.7 | 94.1 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 74.5 | 76.0 | 69.1 | 90.3 | 6281 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 18.0 | 35.0 | 53.5 | 115.9 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 17.6 | 31.0 | 67.4 | 136.2 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 33.4 | 54.0 | 66.4 | 143.9 | 6281 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 69.0 | 96.0 | 64.3 | 89.7 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 72.3 | 99.0 | 73.8 | 91.5 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 40.3 | 76.0 | 71.3 | 97.0 | 6281 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 35.0 | 79.0 | 69.1 | 124.7 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 34.6 | 99.0 | 87.7 | 136.1 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 63.5 | 81.0 | 61.9 | 126.5 | 6281 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 76.5 | 96.0 | 86.2 | 107.9 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 82.5 | 99.0 | 82.9 | 94.5 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 73.7 | 82.0 | 89.2 | 111.5 | 6281 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 25.1 | 50.0 | 49.2 | 78.7 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 29.1 | 53.0 | 57.7 | 135.2 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 55.0 | 99.0 | 86.9 | 176.5 | 6281 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 63.6 | 94.0 | 70.2 | 105.5 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 63.6 | 99.0 | 74.3 | 94.2 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 57.0 | 83.0 | 66.4 | 106.3 | 6281 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 25.7 | 99.0 | 72.1 | 130.7 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 25.6 | 100.0 | 53.3 | 83.2 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 46.0 | 99.0 | 78.0 | 149.1 | 6281 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 45.9 | 100.0 | 68.0 | 107.9 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 47.2 | 99.0 | 67.4 | 95.6 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 49.7 | 99.0 | 69.6 | 107.9 | 6281 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 9 | NVIDIA P104-100 | Gen1 x1 | 52.0 | 92.0 | 67.9 | 154.0 | 7561 |
| 10 | NVIDIA P104-100 | Gen1 x1 | 66.0 | 99.0 | 71.5 | 120.8 | 6277 |
| 11 | NVIDIA P104-100 | Gen1 x1 | 61.7 | 84.0 | 69.7 | 104.7 | 6281 |


## CPU / RAM / swap load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 12.2 %, max 12.2 %

RAM used: avg 4326 MiB, max 4326 MiB, avg 27.3 %, max 27.3 %

Swap used: avg 4363 MiB, max 4363 MiB, avg 17.8 %, max 17.8 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 7.5 | 7.5 |
| 1 | 29.3 | 29.3 |
| 2 | 3.1 | 3.1 |
| 3 | 8.9 | 8.9 |

Decode stage:

CPU total: avg 30.1 %, max 35.7 %

RAM used: avg 5183 MiB, max 5498 MiB, avg 32.6 %, max 34.6 %

Swap used: avg 4428 MiB, max 4428 MiB, avg 18.0 %, max 18.0 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 7.9 | 13.0 |
| 1 | 11.0 | 24.5 |
| 2 | 92.3 | 100.0 |
| 3 | 9.1 | 13.4 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 31.5 %, max 35.0 %

RAM used: avg 5743 MiB, max 5745 MiB, avg 36.2 %, max 36.2 %

Swap used: avg 4428 MiB, max 4428 MiB, avg 18.0 %, max 18.0 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 12.5 | 22.6 |
| 1 | 4.5 | 5.7 |
| 2 | 99.5 | 100.0 |
| 3 | 9.2 | 11.8 |

Decode stage:

CPU total: avg 31.0 %, max 33.8 %

RAM used: avg 5679 MiB, max 5736 MiB, avg 35.8 %, max 36.1 %

Swap used: avg 4428 MiB, max 4428 MiB, avg 18.0 %, max 18.0 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 9.6 | 13.0 |
| 1 | 11.1 | 14.4 |
| 2 | 92.6 | 100.0 |
| 3 | 10.5 | 12.5 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 23.6 %, max 37.0 %

RAM used: avg 5973 MiB, max 6166 MiB, avg 37.6 %, max 38.8 %

Swap used: avg 4439 MiB, max 4439 MiB, avg 18.1 %, max 18.1 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 7.9 | 15.7 |
| 1 | 71.7 | 100.0 |
| 2 | 5.9 | 14.7 |
| 3 | 8.9 | 16.7 |

Decode stage:

CPU total: avg 33.5 %, max 36.7 %

RAM used: avg 6022 MiB, max 6057 MiB, avg 37.9 %, max 38.2 %

Swap used: avg 4439 MiB, max 4439 MiB, avg 18.1 %, max 18.1 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 9.8 | 13.4 |
| 1 | 99.7 | 100.0 |
| 2 | 11.7 | 16.9 |
| 3 | 12.4 | 18.6 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 33.8 %, max 37.2 %

RAM used: avg 6571 MiB, max 6608 MiB, avg 41.4 %, max 41.6 %

Swap used: avg 4510 MiB, max 4510 MiB, avg 18.4 %, max 18.4 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 13.6 | 17.2 |
| 1 | 98.0 | 100.0 |
| 2 | 11.6 | 17.6 |
| 3 | 11.7 | 16.7 |

Decode stage:

CPU total: avg 32.8 %, max 33.5 %

RAM used: avg 6503 MiB, max 6509 MiB, avg 41.0 %, max 41.0 %

Swap used: avg 4510 MiB, max 4510 MiB, avg 18.4 %, max 18.4 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 10.3 | 11.8 |
| 1 | 99.9 | 100.0 |
| 2 | 10.6 | 13.0 |
| 3 | 10.3 | 12.6 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 26.7 %, max 37.1 %

RAM used: avg 6942 MiB, max 7201 MiB, avg 43.7 %, max 45.4 %

Swap used: avg 4542 MiB, max 4555 MiB, avg 18.5 %, max 18.5 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 12.5 | 27.8 |
| 1 | 66.0 | 100.0 |
| 2 | 11.2 | 24.2 |
| 3 | 16.7 | 67.9 |

Decode stage:

CPU total: avg 32.6 %, max 34.7 %

RAM used: avg 7080 MiB, max 7106 MiB, avg 44.6 %, max 44.8 %

Swap used: avg 4613 MiB, max 4635 MiB, avg 18.8 %, max 18.9 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 32.4 | 96.3 |
| 1 | 76.5 | 100.0 |
| 2 | 12.0 | 19.1 |
| 3 | 9.4 | 12.6 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

CPU total: avg 24.7 %, max 37.3 %

RAM used: avg 6333 MiB, max 7239 MiB, avg 39.9 %, max 45.6 %

Swap used: avg 5390 MiB, max 5875 MiB, avg 21.9 %, max 23.9 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 43.8 | 100.0 |
| 1 | 13.1 | 40.4 |
| 2 | 24.7 | 100.0 |
| 3 | 17.1 | 81.4 |

Decode stage:

CPU total: avg 33.9 %, max 36.8 %

RAM used: avg 6197 MiB, max 6337 MiB, avg 39.0 %, max 39.9 %

Swap used: avg 5136 MiB, max 5137 MiB, avg 20.9 %, max 20.9 %

| Logical CPU | avg util % | max util % |
|---:|---:|---:|
| 0 | 11.9 | 25.2 |
| 1 | 13.4 | 25.8 |
| 2 | 99.7 | 100.0 |
| 3 | 10.4 | 15.8 |

